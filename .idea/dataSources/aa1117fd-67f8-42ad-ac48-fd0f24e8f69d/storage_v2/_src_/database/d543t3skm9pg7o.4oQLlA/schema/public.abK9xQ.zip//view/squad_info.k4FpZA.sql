create view squad_info
            (id, id_squad_creator, name, surname, sport, max_members, fee, id_place, place, city, street, date,
             photo) as
SELECT squads.id,
       users.id    AS id_squad_creator,
       user_details.name,
       user_details.surname,
       squads.sport,
       squads.max_members,
       squads.fee,
       places.id_place,
       places.name AS place,
       places.city,
       places.street,
       squads.date,
       user_details.photo
FROM (((squads
    JOIN users ON ((users.id = squads.id_squad_creator)))
    JOIN user_details ON ((users.id_user_details = user_details.id_user_details)))
         JOIN places ON ((squads.id_place = places.id_place)));

